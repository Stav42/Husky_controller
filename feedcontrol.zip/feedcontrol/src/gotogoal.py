#!/usr/bin/env python
import rospy
import time
from tf.transformations import euler_from_quaternion
from geometry_msgs.msg  import Twist,PoseArray
from geometry_msgs.msg import Pose
from nav_msgs.msg import Odometry
from std_msgs.msg import Int32,Float32MultiArray
from math import pow,atan2,sqrt,pi
from numpy import arctan


class huskybot():

    def __init__(self):
        #Creating our node,publisher and subscriber
        rospy.init_node('husky_controller', anonymous=True)
        self.velocity_publisher = rospy.Publisher('/husky_velocity_controller/cmd_vel', Twist, queue_size=10)
	self.euler_pub = rospy.Publisher('yaw',Int32, queue_size=100)
        self.waypoint_sub = rospy.Subscriber('/Nav',PoseArray,self.getempoints)	
	self.odo_subscriber = rospy.Subscriber('/odometry/filtered', Odometry, self.callback)
        self.odo = Odometry()
	self.waypoints = PoseArray()        
	self.rate = rospy.Rate(10)
	
    #Callback function implementing the pose value received
    def getempoints(self, data):
        self.waypoints = data

    def callback(self, data):
        self.odo = data
        self.odo.pose.pose.position.x = round(self.odo.pose.pose.position.x, 4)
        self.odo.pose.pose.position.y = round(self.odo.pose.pose.position.y, 4)

    def get_distance(self, goal_x, goal_y):
        distance = sqrt(pow((goal_x - self.odo.pose.pose.position.x), 2) + pow((goal_y - self.odo.pose.pose.position.y), 2))
        return distance

    

    def move2goal(self):
        goal_odo = Odometry()
	distance_tolerance = input("Set your tolerance:")	
	#print("x1 x2 is",self.waypoints.poses[0].position.y,self.waypoints.poses[1].position.x)        
 	                
	for j in range(int(self.waypoints.poses[0].position.z)):
		#print("checkpoint")
		goal_odo.pose.pose.position.x = self.waypoints.poses[j].position.x
		#goal_odo.pose.pose.position.x = 2 
		#goal_odo.pose.pose.position.y = 6       	
		goal_odo.pose.pose.position.y = self.waypoints.poses[j].position.y
        	
	        vel_msg = Twist()
	
		#print("x1 is and y1 is",goal_odo.pose.pose.position.x,goal_odo.pose.pose.position.y)        
 	        
		while self.get_distance(goal_odo.pose.pose.position.x,goal_odo.pose.pose.position.y) >= distance_tolerance :
			#print("x1 is and x2 is",self.waypoints.poses[0].position.y,self.waypoints.poses[1].position.x)        
 	        
	            	(roll, pitch,theta) = euler_from_quaternion([self.odo.pose.pose.orientation.x,self.odo.pose.pose.orientation.y, self.odo.pose.pose.orientation.z, self.odo.pose.pose.orientation.w])
 	    		if theta<0:
				theta = theta + 2*pi
	    		dely = goal_odo.pose.pose.position.y - self.odo.pose.pose.position.y
            		delx = goal_odo.pose.pose.position.x - self.odo.pose.pose.position.x
	    		angle = atan2(dely,delx)
			if angle<0:
				angle = angle+2*pi	
			#print('dely and delx are',dely,delx)
	   # if (delx)<0:	
	    #	beta = -angle
	    #if delx>=0:
		#beta = -angle+2*pi
		
	    #gamma= beta+pi/2
	
	    #if delx>=0 and dely>0:
		#gamma = gamma%(2*pi)	
	   
	    		distance = self.get_distance(goal_odo.pose.pose.position.x,goal_odo.pose.pose.position.y)
	    #Porportional Controller
            #linear velocity in the x-axis:
            		vel_msg.linear.x = 0.6*distance
            		vel_msg.linear.y = 0
            		vel_msg.linear.z = 0
	   #abs(-abs(theta-angle)+2*pi)*distance*0.3
	    

	    		if abs(theta-angle)>0.05 :           			
				
				if(abs(theta-angle)>pi):
					vel_msg.angular.x = 0
            				vel_msg.angular.y = 0
					if (theta-angle)>0:
						if distance<1:
							vel_msg.angular = 0.3
						else :
							vel_msg.angular.z = +0.4* abs(theta-angle)*distance*0.3
	                                elif(theta-angle)<0:
						if distance<1:	   
							vel_msg.angular = -0.3
						else :
							vel_msg.angular.z = -0.4* abs(theta-angle)*distance*0.3					
				
    				elif(abs(theta-angle)<pi):
										
					vel_msg.angular.x = 0
					vel_msg.angular.y = 0
										
					if theta-angle>0:					
						if distance<1:			
							vel_msg.angular.z = -0.3
						else :
							vel_msg.angular.z = -0.4*abs(theta-angle)*distance*0.3						
					elif theta-angle<0:
						if distance<1:						
							vel_msg.angular.z = +0.3
						else :
							vel_msg.angular.z = +0.4*abs(theta-angle)*distance*0.3						    		
			else : 
				vel_msg.angular.x=0
	    			vel_msg.angular.y=0
				vel_msg.angular.z=0

    	 #   		print"delta y is ",goal_odo.pose.pose.position.y - self.odo.pose.pose.position.y
	  #  		print"delta x is ",goal_odo.pose.pose.position.x - self.odo.pose.pose.position.x
  	
            #Publishing our vel_msg
           		print"distance is ",distance	
		
	    		self.velocity_publisher.publish(vel_msg)
            		self.rate.sleep()
			
        #Stopping our robot after the movement is over
       		vel_msg.linear.x = 0
        	vel_msg.angular.z =0
        	self.velocity_publisher.publish(vel_msg)
		time.sleep(2)
	        
	rospy.spin()

if __name__ == '__main__':
    try:
        #Testing our function
        x = huskybot()
        x.move2goal()
	
    except rospy.ROSInterruptException: pass

