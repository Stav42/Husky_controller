#!/usr/bin/env python

import rospy
from geometry_msgs.msg import Point,PoseArray,Pose


def  msg():
	pub = rospy.Publisher('Nav',PoseArray,queue_size =100)
	rospy.init_node('coordinates',anonymous =True)
	rate = rospy.Rate(10)
	num = input("number of points: ")
	data = PoseArray()
	for i in range(num):
		point = Pose()		
		point.position.z = num		
		point.position.x = input("Enter X: ")
		point.position.y = input("Enter Y: ")
		data.poses.append(point)

	while not  rospy.is_shutdown() :
		#print("x is ",data.poses[1].position.x)		
		pub.publish(data)
		rate.sleep()

if __name__ == '__main__':
	try:
		msg()
	except rospy.ROSInterruptException:
		pass
